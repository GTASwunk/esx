Locales['de'] = {
  ['activated']   = 'Aktiviert',
  ['deactivated'] = 'Deaktiviert',
}
