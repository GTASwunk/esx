Locales['ge'] = {
  ['activated']   = 'aktiviert',
  ['deactivated'] = 'deaktiviert',
}
