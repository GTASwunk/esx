# fxserver-es_camera
Spectator camera for FiveM

[REQUIREMENTS]

essentialmode + es_admin => https://forum.fivem.net/t/release-essentialmode-base/3665

[INSTALLATION]

```
cd in your resources/[essential] directory
git clone https://github.com/FXServer-ESX/fxserver-es_camera es_camera
```

[INFOS]

Type /spectate [id] to spectate someone

Type /spectate to exit spectator mode
