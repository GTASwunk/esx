Locales['br'] = {
  ['skin_menu'] = 'Skin Menu',
  ['use_rotate_view'] = 'Use ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ e ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ para girar a visão.',
  ['skin'] = 'Trocar',
  ['saveskin'] = 'Salvar',
}
