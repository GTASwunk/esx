Config = {}

Config.Locale = 'fr'
