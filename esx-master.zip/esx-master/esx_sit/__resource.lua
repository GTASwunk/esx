resource_manifest_version '05cfa83c-a124-4cfa-a768-c24a5811d8f9'

version '1.0.3'

client_scripts {
	'config.lua',
	'lists/seat.lua',
	'client.lua'
}

server_scripts {
	'config.lua',
	'lists/seat.lua',
	'server.lua'
}