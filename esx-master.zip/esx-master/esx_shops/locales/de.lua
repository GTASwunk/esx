Locales['de'] = {
  ['shop'] = 'geschäft',
  ['shops'] = 'geschäfte',
  ['press_menu'] = 'drücke ~INPUT_CONTEXT~ um auf das Geschäft zuzugreifen.',
  ['shop_item'] = '$%s',
  ['bought'] = 'Du hast ~y~%sx~s~ ~b~%s~s~ für ~r~$%s~s~ Gekauft',
  ['not_enough'] = 'du ~r~hast nicht~s~ genug geld: %s',
  ['player_cannot_hold'] = 'Du hast nicht genug Platz im Inventar!',
  ['shop_confirm'] = 'Kaufe %sx %s für  $%s?',
  ['no'] = 'Nein',
  ['yes'] = 'Ja',
}
