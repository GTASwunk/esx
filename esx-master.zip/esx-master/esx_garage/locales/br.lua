Locales['br'] = {
	['veh_released'] = 'veículo ~g~já está disponivel',
	['veh_stored'] = 'veículo ~g~guardado',
	['veh_health'] = 'you\'ll have to repair the vehicle before storing it.',
}
