Locales['de'] = {
	
	['used_beer'] = 'Du hast 1x ~y~Beer~s~ verwendet.',

}
